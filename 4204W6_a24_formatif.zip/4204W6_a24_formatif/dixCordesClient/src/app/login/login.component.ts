import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  loginUsername : string = "";
  loginPassword : string = "";

  registerUsername : string = "";
  registerPassword : string = "";
  registerPasswordConfirm : string = "";

  constructor(public authService : AuthService) { }

  login(){
    if(this.loginUsername && this.loginPassword){
      this.authService.loginRequest(this.loginUsername, this.loginPassword);
    }
  }

  register(){
    if(this.registerUsername && this.registerPassword && this.registerPasswordConfirm){
      this.authService.registerRequest(this.registerUsername, this.registerPassword, this.registerPasswordConfirm);
    }
  }

  ngOnInit() {
  }
}
